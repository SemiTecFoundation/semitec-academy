module shift4 (
  input  logic       clk, rst, d_in,
  output logic [3:0] q
);
  // TODO: describe the shift register (Lab 1, step 2)
endmodule
