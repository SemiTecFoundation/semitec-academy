module tb_shift4;
  logic clk = 0, rst = 1, d_in = 0;
  logic [3:0] q;
  shift4 dut (.*);
  always #5 clk = ~clk;
  initial begin
    // TODO: reset, shift in 1,0,1,1 and check q == 4'b1011
    $finish;
  end
endmodule
