Lab 1 starter files: copy them into your Vivado project.
